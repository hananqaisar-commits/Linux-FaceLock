@echo off
setlocal EnableExtensions
title NovaUnlock Windows Installer

net session >nul 2>&1
if not "%errorLevel%"=="0" (
    echo [ERROR] Administrator privileges are required.
    echo Right-click install.bat and choose Run as administrator.
    pause
    exit /b 1
)

set "PY=py -3.13"
%PY% -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 13) else 1)" >nul 2>&1
if not "%errorLevel%"=="0" (
    echo [INFO] Python 3.13 is required for the packaged NovaUnlock runtime.
    where winget >nul 2>&1
    if not "%errorLevel%"=="0" (
        echo [ERROR] Python 3.13 was not found and winget is unavailable.
        echo Install Python 3.13 from python.org, then run this installer again.
        pause
        exit /b 1
    )
    winget install --id Python.Python.3.13 -e --silent --accept-package-agreements --accept-source-agreements
    %PY% -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 13) else 1)" >nul 2>&1
    if not "%errorLevel%"=="0" (
        echo [ERROR] Python 3.13 installation was not detected.
        echo Restart this installer after Python setup finishes.
        pause
        exit /b 1
    )
)

set "SRC=%~dp0"
set "NOVA_PATH=%ProgramData%\NovaUnlock"
set "STARTUP_FOLDER=%ProgramData%\Microsoft\Windows\Start Menu\Programs\StartUp"

if not exist "%NOVA_PATH%" mkdir "%NOVA_PATH%"
if not exist "%NOVA_PATH%\data" mkdir "%NOVA_PATH%\data"
if not exist "%NOVA_PATH%\data\faces" mkdir "%NOVA_PATH%\data\faces"
xcopy "%SRC%nova_unlock_win" "%NOVA_PATH%\nova_unlock_win\" /E /I /Y >nul
xcopy "%SRC%scripts" "%NOVA_PATH%\scripts\" /E /I /Y >nul
if exist "%SRC%credential_provider" xcopy "%SRC%credential_provider" "%NOVA_PATH%\credential_provider\" /E /I /Y >nul

echo [INFO] Installing Windows runtime dependencies...
where winget >nul 2>&1
if "%errorLevel%"=="0" (
    winget install --id Microsoft.VCRedist.2015+.x64 -e --silent --accept-package-agreements --accept-source-agreements
)

%PY% -m ensurepip --upgrade
%PY% -m pip install --upgrade pip setuptools wheel
if exist "%SRC%requirements.txt" %PY% -m pip install -r "%SRC%requirements.txt"
%PY% -c "import cv2, numpy, face_recognition, PyQt5, yaml"
if not "%errorLevel%"=="0" (
    echo [ERROR] Required Python dependencies are not installed correctly.
    echo Check the pip output above, then run this installer again.
    pause
    exit /b 1
)

if not exist "%NOVA_PATH%\config" mkdir "%NOVA_PATH%\config"
(
    echo [auth]
    echo windows_user=%USERNAME%
) > "%NOVA_PATH%\config\nova.conf"

echo [INFO] Enrolling Windows password secret for Credential Provider use.
echo You will be asked for the Windows password for %USERNAME%.
%PY% "%NOVA_PATH%\scripts\windows_enroll_password.pyc"
if not "%errorLevel%"=="0" (
    echo [ERROR] Password enrollment failed. Credential Provider registration was not completed.
    pause
    exit /b 1
)

echo [INFO] Enrolling face profile for %USERNAME%.
%PY% "%NOVA_PATH%\scripts\windows_enroll_face.pyc"
if not "%errorLevel%"=="0" (
    echo [ERROR] Face enrollment failed. Credential Provider registration was not completed.
    pause
    exit /b 1
)

set "DAEMON=%NOVA_PATH%\scripts\windows_daemon.pyc"
if not exist "%DAEMON%" (
    echo [WARN] Windows daemon bytecode not found: %DAEMON%
) else (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%STARTUP_FOLDER%\NovaUnlockDaemon.lnk'); $s.TargetPath='pythonw.exe'; $s.Arguments='""%DAEMON%""'; $s.WorkingDirectory='%NOVA_PATH%'; $s.Save()"
)

if exist "%NOVA_PATH%\credential_provider\NovaUnlockProvider.dll" (
    regsvr32 /s "%NOVA_PATH%\credential_provider\NovaUnlockProvider.dll"
    reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\Credential Providers\{A1234567-B890-12CD-34EF-567890ABCDEF}" /ve /d "NovaUnlockProvider" /f
    reg add "HKCR\CLSID\{A1234567-B890-12CD-34EF-567890ABCDEF}" /ve /d "NovaUnlockProvider" /f
    reg add "HKCR\CLSID\{A1234567-B890-12CD-34EF-567890ABCDEF}\InprocServer32" /ve /d "%NOVA_PATH%\credential_provider\NovaUnlockProvider.dll" /f
    reg add "HKCR\CLSID\{A1234567-B890-12CD-34EF-567890ABCDEF}\InprocServer32" /v "ThreadingModel" /d "Apartment" /f
) else (
    echo [WARN] Native Credential Provider DLL not included. Base daemon files were installed only.
)

echo [OK] NovaUnlock Windows files installed to %NOVA_PATH%.
pause
